# codesaya-git

Jika anda ingin belajar Git, buka https://codesaya.com/git/

Repositori (repo) ini akan menjadi objek untuk pembelajaran anda. Step-step yang harus anda lakukan dengan repo ini bisa dilihat di web CodeSaya.

-CodeSaya, tempat belajar coding seru, mudah, dan gratis!
