# codesaya-git
Repository for Git class in http://CodeSaya.com

**Next section is written in Bahasa Indonesia**

Jika anda ingin belajar Git, buka http://codesaya.com/git/

Repositori (repo) ini akan menjadi objek untuk pembelajaran anda. Step-step yang harus anda lakukan dengan repo ini bisa dilihat di web CodeSaya.

**FAQ**

*masih kosong*

-CodeSaya
